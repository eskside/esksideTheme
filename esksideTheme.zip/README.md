# esksideTheme for Brackets

A Brackets theme developed by [Eskside Design](https://esksidedesign.co.uk).

This theme is free to use and edit as you see fit.